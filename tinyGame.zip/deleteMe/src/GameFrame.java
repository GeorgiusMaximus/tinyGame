import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

public class GameFrame extends JFrame implements ActionListener {

    public JButton button;
    public static int buttonX;
    public static int buttonY;


    public static ImageIcon settingsIcon;

    public JMenuBar menuBar;
    JMenu fileMenu;

    public JMenuItem settings;

    Random random;

    public JLabel clicks;

    public int clickCounter = 0;

    public GameFrame(){

        settings = new JMenuItem("Settings");
        settings.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new SettingsWindow();
            }
        });

        fileMenu = new JMenu("File");
        fileMenu.add(settings);
        menuBar = new JMenuBar();
        menuBar.add(fileMenu);
        clicks = new JLabel();
        clicks.setText("clicks: " + clickCounter);
        this.add(clicks);
        clicks.setBounds(10, 30, 80, 20);
        clicks.setOpaque(true);
        random = new Random();
        button = new JButton();
        buttonX = random.nextInt(100, 500);
        buttonY = random.nextInt(100, 300);
        this.add(button);
        button.setBounds(buttonX, buttonY, 50, 25);
        button.addActionListener(this);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(600, 400);
        this.setResizable(false);
        this.setLayout(null);
        this.setLocationRelativeTo(null);
        this.setJMenuBar(menuBar);
        this.setVisible(true);

    }


    @Override
    public void actionPerformed(ActionEvent e) {


        if (e.getSource() == button){
            buttonX = random.nextInt(1, 500);
            buttonY = random.nextInt(1, 300);
            button.setBounds(buttonX, buttonY, 50, 25);
            clickCounter++;
            System.out.println(clickCounter);
            clicks.setText("clicks: " + clickCounter);
        }


    }
}
